<?php $__env->startSection('JudulHalaman','Sertifikat Saya'); ?>

<?php $__env->startSection('CssTambahanAfter'); ?>
<link rel="stylesheet" href="<?php echo e(asset('css/style-yusuf.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('css/checkbox-custom.css')); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('header'); ?>
<?php echo $__env->make('template.components.nav-common', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('konten'); ?>
<?php if(!$data["is_email_verify"]): ?>
<div class="container">
    <div class="card" id="emailVerification">
        <div class="d-flex flex-sm-row justify-content-between">
            <div class="d-flex">
                <img src='<?php echo e(asset("icons/warning-24px.svg")); ?>'>
                <p>Email belum diverifikasi.</p>
            </div>
            <div>
                <a style="text-decoration:none" href="<?php echo e(route('kirimUlang')); ?>">
                    <p>Kirim Ulang</p>
                </a>
            </div>
        </div>
    </div>
</div>
<?php endif; ?>
<div class="container" id="kelolaSertifikat">

    <h2>Sertifikat saya</h2>

    <div class="input-group mb-5">
        <input type="text" class="form-control search" onkeyup="search()" id="src_in" placeholder="Nama atau Email">
    </div>

    <form>
        <div class="table-responsive my-custom-scrollbar" id="style-2">
            <table class="table" id="tabel_list">
                <thead class="thead-dark">
                    <tr class="tableHead">
                        
                        <th scope="col">ID Sertifikat</th>
                        <th scope="col">Nama Acara</th>
                        
                        <th scope="col" class="colHide">Tanggal Rilis</th>
                        <th scope="col" class="colHide">Berlaku Sampai</th>
                        
                    </tr>
                </thead>
                <tbody>
                    <?php if(!$data["is_email_verify"]): ?>
                    <tr>
                        <th colspan="100%" class="text-center">Verifikasi Email Untuk Melihat Sertifikat.</th>
                    </tr>
                    <?php else: ?>
                    <?php $__currentLoopData = $data["sertif"]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                    <tr onclick="liat('<?php echo e($d->id); ?>')" class="clickable">
                        <td>#<?php echo e($d->id); ?></td>
                        <td><?php echo e($d->name); ?></td>
                        <td class="colHide">
                            <?php echo e(\Carbon\Carbon::parse($d->release_date)->formatLocalized("%A, %d %B %Y")); ?>

                        </td>
                        <td class="colHide">
                            <?php echo e($d->valid_until == ""? "Selamanya":\Carbon\Carbon::parse($d->valid_until)->formatLocalized("%A, %d %B %Y")); ?>

                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php if(count($data["sertif"]) == 0 && $data["is_email_verify"] != ""): ?>
                        
                        <tr>
                            <th colspan="100%" class="text-center">Anda belum memiliki sertifikat</th>
                        </tr>
                        <?php endif; ?>
                    <?php endif; ?>


                </tbody>
            </table>
        </div>
    </form>

</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('JsTambahanAfter'); ?>
<script src="<?php echo e(asset('js/page/sertifikat_saya.js')); ?>">
</script>
<script>
    function liat(id){
        window.open("/certificate/"+id);
    }
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('template.all', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\certifett\resources\views/frontend/sertifikatSaya.blade.php ENDPATH**/ ?>