<?php $__env->startSection('JudulHalaman','Sertifikat'); ?>

<?php $__env->startSection('CssTambahanAfter'); ?>

<?php $__env->stopSection(); ?>
<style>
    @font-face {
        font-family: "Verdana" !important;
        src: url('/assets/webfonts/verdana.ttf') !important;
    }
    #sertifikat{
        font-family: "Verdana" !important;
    }
    @media  screen and (max-width: 800px) {
        .header h1 {
            font-size: 18px;
        }
    }
</style>
<?php $__env->startSection('header'); ?>
<?php echo $__env->make('template.components.nav-common', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('konten'); ?>
<div class="container mt-4">
    <div class="d-flex justify-content-between header" style="margin-bottom:20px">
        <h1>Sertifikat Terverifikasi</h1>
        <button class="btn btn-outline-dark" id="btn_dwnld"><i class="fa fa-download" aria-hidden="true"> Download
                Sertifikat</i></button>
    </div>
    <div class="m-auto" id="sertifikat"
        style="width:1100px; height:fit-content; padding:25px; text-align:center; border: 1px solid #787878;background-color: white;">
        <p class="text-hijau" style="margin-left:-965px">#<?php echo e($data['peserta']->id); ?></p>
        <div style="text-align:center;">
            <div class="d-flex justify-content-center" style="height:60px">
                <img src="<?php echo e(asset($data['sertif']->logo_sertifikat)); ?>" height="60">
                <div
                    style="font-size:60px; font-weight:400;text-decoration-line: underline; line-height:60px; margin-top:-7px;margin-left:20px;color: #263238;text-transform: uppercase;">
                    <?php echo e($data['sertif']->jenis_sertifikat); ?></div>
            </div>

            <br><br>

            <div class="d-flex justify-content-center">
                <img src="<?php echo e(asset($data['sertif']->logo_instansi)); ?>" height="70">
                <div style="text-align:left; margin-left:15px">
                    <h5 class="text-hijau"> INSTANSI</h5>
                    <h5><?php echo e($data['sertif']->nama_instansi); ?></h5>
                </div>
            </div>
            <br>
            <h5 class="text-hijau">Diberikan Kepada</h5>
            <br>
            <h1 style="text-transform: uppercase;"><?php echo e($data['peserta']->name); ?></h1>
            <br>
            <h5 style="font-weight:400"><?php echo e($data['sertif']->alasan); ?></h5>

            <div class="d-flex justify-content-around" style="margin-top:30px;">
                <?php $__currentLoopData = $data['sertif_khusus']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div>
                    <h6 class="text-hijau" style="text-transform: uppercase;"><?php echo e($d->nama); ?></h6>
                    <?php if($d->gambar != null): ?>
                    <img src="<?php echo e(asset($d->gambar)); ?>" height="100">
                    <h6 style="text-transform: uppercase;"><?php echo e($d->data); ?></h6>
                    <?php else: ?>
                    <h6 style="text-transform: uppercase;margin-top: 100px;"><?php echo e($d->data); ?></h6>
                    <?php endif; ?>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('JsTambahanAfter'); ?>
<script src="<?php echo e(asset('js/dom-to-image.min.js')); ?>"></script>
<script src="<?php echo e(asset('js/page/lihat-sertif.js')); ?>"></script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('template.all', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\certifett\resources\views/frontend/lihat-sertif.blade.php ENDPATH**/ ?>