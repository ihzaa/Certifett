<?php $__env->startSection('JudulHalaman',"Ini Halaman contoh"); ?>



<?php $__env->startSection('konten'); ?>

<h1 class="text-success">Ini judul</h1>
<h2>Ini sub judul</h2>
<button class="btn btn-primary">ok suf?</button>

<?php $__env->stopSection(); ?>



<?php echo $__env->make('template.all', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\certifett\resources\views/frontend/contoh.blade.php ENDPATH**/ ?>