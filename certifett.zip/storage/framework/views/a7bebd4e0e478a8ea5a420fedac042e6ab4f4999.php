<?php $__env->startSection('JudulHalaman','Manage Participants'); ?>

<?php $__env->startSection('CssTambahanAfter'); ?>
<link rel="stylesheet" href="<?php echo e(asset('css/style-yusuf.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('css/checkbox-custom.css')); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('header'); ?>
<?php echo $__env->make('template.components.nav-common', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('konten'); ?>
<div class="container kelola" id="kelolaSertifikat">
    <div class="d-flex kelolaPeserta">
        <div>
            <h2>Peserta</h2>
            <p>Daftar peserta yang terdaftar dalam <?php echo e($data["acara"]->name); ?>. Buat sertifikat dengan cara mencentang
                kotak
                disamping kiri nama dan tekan tombol buat di sudut kanan atas tabel. Sertifikat yang telah dibuat dapat
                diunduh oleh peserta melalui <?php echo e(config('app.url')); ?>. Tekan baris
                dari tabel dibawah untuk melihat preview sertifikat.</p>
            <div class="info tengah">
                <img src='<?php echo e(asset("icons/event-24px.svg")); ?>'>
                <h5><?php echo e($data["acara"]->name); ?></h5>
            </div>
            <div class="info">
                <img src='<?php echo e(asset("icons/schedule-24px.svg")); ?>'>
                <h5><?php echo e(\Carbon\Carbon::parse($data['acara']->date)->formatLocalized("%A, %d %B %Y")); ?></h5>
            </div>
            <div class="d-flex kartu">
                <div class="card">
                    <h5>Import from .csv</h5>
                    <p>Export data yang telah ada. Format yang diterima adalah csv. Gunakan ini jika anda telah memiliki
                        data peserta misalnya dari google form.</p>
                    <button type="button" class="btn btn-outline-dark" id="btn-import" data-toggle="modal"
                        data-target="#modal-csv">Import Sekarang</button>
                </div>
                <div class="card">
                    <h5>Share link</h5>
                    <p>Share link ini agar peserta dapat Mendaftar secara mandiri.</p>
                    <div class="d-flex">
                        <p id="linkCertifet">
                            <?php echo e(substr(route('form_pendaftaran_event',['id'=>$data['acara']->id]),0,35)); ?>...
                        </p>
                        <img src="<?php echo e(asset('icons/content_copy-24px.svg')); ?>" id="cpy_btn"
                            onclick="copyToClipboard('<?php echo e(route('form_pendaftaran_event',['id'=>$data['acara']->id])); ?>')"
                            data-toggle="tooltip" title="Salin link">
                    </div>
                </div>
            </div>
        </div>
        <img class="img-fluid" id="bgImage" src='<?php echo e(asset("images/Online Review-pana@2x.png")); ?>'>
    </div>

    <div class="d-flex justify-content-between jumlah">
        <h3>
            <div id="jml_dicentang" class="d-inline">0</div>/ <div id="jml_psrt" class="d-inline">
                <?php echo e($data["jml_peserta"]); ?></div> <span>Peserta dicentang</span>
        </h3>
        <button type="button" class="btn btn-outline-dark" id="buatSertif" href="">Buat
            Sertifikat</button>
    </div>

    <div class="input-group mb-5">
        <input type="text" class="form-control search" onkeyup="search()" id="src_in" placeholder="Nama atau Email">
    </div>

    <form id="form_centang" action="<?php echo e(route('buat_sertifikat',['id' => $data["acara"]->id])); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <div class="table-responsive my-custom-scrollbar" id="style-2">
            <table class="table" id="tabel_list">
                <thead class="thead-dark">
                    <tr class="tableHead">
                        <th scope="col">
                            <label class="check">
                                <input type="checkbox" onchange="checkAll(this)" class="check_header" id="check_header">
                                <span class="check_indicator" id="checkbox_header"></span>
                            </label>
                        </th>
                        <th scope="col">Nama</th>
                        <th scope="col" class="colHide">Email</th>
                        <th scope="col">
                            <a href="#" id="btn-hps-all"><img src='<?php echo e(asset("icons/delete-24px.svg")); ?>'></a>
                        </th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $data["peserta"]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <th scope="row">
                            <label class="check">
                                <input type="checkbox" <?php if($d->release_date == ""): ?> name="chk[<?php echo e($d->id); ?>]" <?php else: ?>
                                name="udh[<?php echo e($d->id); ?>]" <?php endif; ?>
                                class="<?php echo e($d->release_date != "" ? "sudah_dibuat check_input" : "check_input blm_dibuat"); ?>">
                                <span class="check_indicator"></span>
                            </label>
                        </th>
                        <td onclick="previewSertif('<?php echo e($d->name); ?>','<?php echo e($d->id); ?>')" class="clickable">
                            <?php if($d->release_date != ""): ?>
                            <img src="<?php echo e(asset('icons/check_circle-24px.svg')); ?>">
                            <?php endif; ?>
                            <span id="col_nama"><?php echo e($d->name); ?></span>
                        </td>
                        <td class="colHide clickable" id="col_email"
                            onclick="previewSertif('<?php echo e($d->name); ?>','<?php echo e($d->id); ?>')">
                            <?php echo e($d->email); ?></td>
                        <td>
                            <a href="#" class="btn-edit"><img src='<?php echo e(asset("icons/create-24px.svg")); ?>'></a>
                            <a href="#" class="btn-hps"><img src='<?php echo e(asset("icons/delete-24px.svg")); ?>'></a>
                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php if(count($data["peserta"]) == 0): ?>
                    
                    <tr>
                        <th colspan="100%" class="text-center">Tidak ada data peserta</th>
                    </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </form>
    <div id="modal_edit" class="modal fade" tabindex="-1" role="dialog" aria-labelledby="my-modal-title"
        aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="my-modal-title">Edit data</h5>
                    <button class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <form action="" method="POST">
                    <?php echo csrf_field(); ?>
                    <div class="modal-body">
                        <div class="form-group">
                            <label for="">Nama</label>
                            <input id="nama_edit" type="text" class="form-control border-radius-c border-hijau"
                                name="nama" required style="width: 100% !important;">
                        </div>
                        <div class="form-group">
                            <label for="exampleInputEmail1">Email</label>
                            <input id="email_edit" type="email" class="form-control border-radius-c border-hijau"
                                name="email" aria-describedby="emailHelp" required style="width: 100% !important;">
                        </div>
                    </div>
                    <div class="modal-footer d-felx">
                        <button type="submit" class=" ml-auto btn btn-dark">Simpan</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>

<div id="modal-csv" class="modal fade " data-backdrop="static" data-keyboard="false" tabindex="-1" role="dialog"
    aria-labelledby="my-modal-title" aria-hidden="true">
    <div class="modal-dialog modal-lg modal-dialog-centered" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="my-modal-title">Pilih file</h5>
                <button class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <div class="input-group mb-3">
                    <div class="input-group-prepend">
                        <span class="input-group-text" id="inputGroupFileAddon01">Upload</span>
                    </div>
                    <div class="custom-file">
                        <input type="file" class="custom-file-input" id="input-csv"
                            aria-describedby="inputGroupFileAddon01">
                        <label class="custom-file-label" for="input-csv" id="input-csv-label">Choose file .csv</label>
                    </div>
                </div>
                <button type="button" class="btn btn-dark" id="btn-cek-kolom" disabled>Cek Kolom</button>
                <div id="body_bawah_modal" style="display: none;">
                    <hr>
                    <h3>Pilih Kolom Nama:</h3>
                    <div class="btn-group btn-group-toggle" data-toggle="buttons" id="grb-nama"></div>
                    <h3>Pilih Kolom Email:</h3>
                    <div class="btn-group btn-group-toggle" data-toggle="buttons" id="grb-email"></div>
                </div>
            </div>
            <div class="modal-footer d-flex">
                <button type="button" class=" ml-auto btn btn-dark" id="btn-up-csv"
                    style="display: none;">Upload</button>
            </div>
        </div>
    </div>
</div>

<div id="modal-preview" class="modal fade" tabindex="-1" role="dialog" aria-hidden="true">
    <div class="modal-dialog modal-xl modal-dialog-centered" role="document">
        <div class="modal-content">
            <div class="modal-body">
                <div class="m-auto" id="sertifikat"
                    style="width:1100px; height:fit-content; padding:25px; text-align:center; border: 1px solid #787878;background-color: white;">
                    <p class="text-hijau" style="margin-left:-965px" id="id_peserta_prev"></p>
                    <div style="text-align:center;">
                        <div class="d-flex justify-content-center" style="height:60px">
                            <img src="<?php echo e(asset($data['sertif']->logo_sertifikat)); ?>" height="60">
                            <div
                                style="font-size:60px; font-weight:400;text-decoration-line: underline; line-height:60px; margin-top:-7px;margin-left:20px;color: #263238;text-transform: uppercase;">
                                <?php echo e($data['sertif']->jenis_sertifikat); ?></div>
                        </div>

                        <br><br>

                        <div class="d-flex justify-content-center">
                            <img src="<?php echo e(asset($data['sertif']->logo_instansi)); ?>" height="70">
                            <div style="text-align:left; margin-left:15px">
                                <h5 class="text-hijau"> INSTANSI</h5>
                                <h5><?php echo e($data['sertif']->nama_instansi); ?></h5>
                            </div>
                        </div>
                        <br>
                        <h5 class="text-hijau">Diberikan Kepada</h5>
                        <br>
                        <h1 style="text-transform: uppercase;" id="nama_peserta_modal"></h1>
                        <br>
                        <h5 style="font-weight:400"><?php echo e($data['sertif']->alasan); ?></h5>

                        <div class="d-flex justify-content-around" style="margin-top:30px;">
                            <?php $__currentLoopData = $data['khusus']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div>
                                <h6 class="text-hijau" style="text-transform: uppercase;"><?php echo e($d->nama); ?></h6>
                                <?php if($d->gambar != null): ?>
                                <img src="<?php echo e(asset($d->gambar)); ?>" height="100">
                                <h6 style="text-transform: uppercase;"><?php echo e($d->data); ?></h6>
                                <?php else: ?>
                                <h6 style="text-transform: uppercase;margin-top: 100px;"><?php echo e($d->data); ?></h6>
                                <?php endif; ?>

                            </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>


<?php $__env->stopSection(); ?>

<?php $__env->startSection('JsTambahanAfter'); ?>
<script>
    const path = {
        ev : "<?php echo e(route('tambah_peserta_csv',['id'=>$data['id']])); ?>",
        ps : "<?php echo e(route('hapus_peserta')); ?>",
        psb : "<?php echo e(route('hapus_peserta_banyak')); ?>"
    }
</script>
<script src="<?php echo e(asset('js/notify.min.js')); ?>"></script>
<script src="<?php echo e(asset('js/papaparse.min.js')); ?>"></script>
<script src="<?php echo e(asset('js/axios.min.js')); ?>"></script>
<script src="<?php echo e(asset('js/page/kelola-peserta.js')); ?>">
</script>
<?php if(Session::get('message')): ?>
<script>
    swal("Berhasil",'<?php echo e(Session::get('message')); ?>' , "success");
</script>

<?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('template.all', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\certifett\resources\views/frontend/kelolaPeserta.blade.php ENDPATH**/ ?>