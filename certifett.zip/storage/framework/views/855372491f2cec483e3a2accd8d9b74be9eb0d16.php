<?php $__env->startSection('JudulHalaman','Pendaftaran Peserta'); ?>

<?php $__env->startSection('CssTambahanAfter'); ?>
<style>
    .container {
        width: 50%
    }

    .card {
        margin-top: 100px;
        padding: 30px;
        box-shadow: 1px 3px 6px #00000029;
    }

    .header {
        text-align: center;
    }

    small {
        margin-left: 10px;
    }

    @media  screen and (max-width: 850px) {
        .container {
            width: 90%;
        }

        h3 {
            font-size: 18px;
        }
    }
</style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('header'); ?>
<?php echo $__env->make('template.components.nav-common', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('konten'); ?>
<div class="container">

    <div class="card border-radius-c">

        <div class="header">
            <h3>Form Pendaftaran Peserta Event <?php echo e($data['nama']); ?></h3>
        </div>
        <div class="dropdown-divider mb-5"></div>
        <form action="<?php echo e(route('peserta_daftar_link',['id'=>$data['id']])); ?>" method="POST">
            <?php echo csrf_field(); ?>
            <div class="mb-4">
                <div class="form-group">
                    <input type="text" class="form-control border-radius-c border-hijau" name="nama" placeholder="Nama"
                        required>
                    <small id="emailHelp" class="form-text text-muted">Nama yang diinputkan pada sertifikat.</small>
                </div>
            </div>
            <div>
                <div class="form-group">
                    <input type="email" class="form-control border-radius-c border-hijau" name="email"
                        placeholder="Email" aria-describedby="emailHelp" required>
                    <small id="emailHelp" class="form-text text-muted">Email pengiriman sertifikat.</small>
                </div>
            </div>
            <div class="dropdown-divider mt-5"></div>
            <div class="mt-4" style="text-align:center">
                <button type="submit" class="btn btn-success btn-lg shadow">Daftar</button>
            </div>

        </form>

    </div>
</div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('JsTambahanAfter'); ?>
<?php if(Session::get('message')): ?>
<script>
    swal("Pendaftaran Berhasil.","","success");
</script>
<?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('template.all', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\certifett\resources\views/frontend/FormDaftarPeserta.blade.php ENDPATH**/ ?>