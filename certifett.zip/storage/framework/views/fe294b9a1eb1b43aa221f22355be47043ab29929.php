<?php $__env->startSection('JudulHalaman','Agency Home'); ?>

<?php $__env->startSection('CssTambahanAfter'); ?>
<link rel="stylesheet" href="<?php echo e(asset('css/style-yusuf.css')); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('header'); ?>
<?php echo $__env->make('template.components.nav-common', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('konten'); ?>
<div class="container">
    <?php if(!$data["is_email_verify"]): ?>
    <div class="card" id="emailVerification">
        <div class="d-flex flex-sm-row justify-content-between">
            <div class="d-flex">
                <img src='<?php echo e(asset("icons/warning-24px.svg")); ?>'>
                <p>Email belum diverifikasi.</p>
            </div>
            <div>
                <a style="text-decoration:none" href="<?php echo e(route('kirimUlang')); ?>">
                    <p>Kirim Ulang</p>
                </a>
            </div>
        </div>
    </div>
    <?php endif; ?>
    <articel id="agencyHome">
        <div class="d-flex justify-content-between box">
            <h1>Acara</h1>
            <a class="btn btn-outline-dark" id="acaraBaru" href="<?php echo e(route('createEvent-page')); ?>">Acara Baru</a>
        </div>
        <div class="d-flex justify-content-between box">
            <div class="input-group" id="list_acara">
                <input type="text" class="form-control search" onkeyup="search()" id="src_in"
                    placeholder="Cari Nama Acara">
            </div>
        </div>
        <div class="d-flex box" id="box_list_acara">
            <?php $i=0; ?>
            <?php $__currentLoopData = $data["acara"]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="box_acara">
                <a href="<?php echo e(route('peserta_acara',['id' => $d->id])); ?>">
                    <div class="card" id="card-<?php echo e($d->id); ?>">
                        <h3 class="nama_acara"><?php echo e($d->name); ?></h3>
                        <p><?php echo e(\Carbon\Carbon::parse($d->date)->formatLocalized("%A, %d %B %Y")); ?></p>
                        <h3><?php echo e($data["jml_peserta"][$i]); ?></h3>
                        <p>Peserta</p>
                        <h3><?php echo e($data["jml_dibuat"][$i++]); ?></h3>
                        <p>Sertifikat Dibuat</p>
                        <div class="edit">
                            <a href="#" @click="hapusKah('<?php echo e($d->id); ?>')"><img
                                    src='<?php echo e(asset("icons/delete-24px.svg")); ?>'></a>
                            <a href="<?php echo e(route('tampil_edit_acara',['id' => $d->id])); ?>"><img
                                    src='<?php echo e(asset("icons/create-24px.svg")); ?>'></a>
                        </div>
                    </div>
                </a>
            </div>

            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </articel>
    <?php if(!count($data["acara"])): ?>
    <div class="row mt-5">
        <div class="col-10 col-lg-8 col-md-8 col-sm-10 border border-radius-c d-flex ml-auto mr-auto">
            <div class="text-center ml-auto mr-auto">
                <p class="mt-3">Anda Belum Memiliki Acara</p>
            </div>
        </div>
    </div>
    <?php endif; ?>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('JsTambahanAfter'); ?>
<script src="<?php echo e(asset('js/axios.min.js')); ?>"></script>
<script src="<?php echo e(asset('js/vue.min.js')); ?>"></script>
<script>
    function search() {
    // Declare variables
    var input, filter, table, tr, td, i, txtValue;
    input = document.getElementById("src_in");
    filter = input.value.toUpperCase();
    box_list = document.getElementById("box_list_acara");
    box = box_list.getElementsByClassName("box_acara");

    // Loop through all table rows, and hide those who don't match the search query
    for (i = 0; i < box.length; i++) {
        td_nama = box[i].getElementsByClassName("nama_acara")[0];
        if (td_nama) {
            txtNama = td_nama.innerText.toUpperCase();
            if (
                txtNama.toUpperCase().indexOf(filter) > -1
            ) {
                box[i].style.display = "";
            } else {
                box[i].style.display = "none";
            }
        }
    }
}
    var app = new Vue({
        el: '#agencyHome',
        data: {
            id_hapus: "",
        },
        methods: {
            hapusKah: function(id=0){

                event.preventDefault();
                swal({
                    title: "Yakin menghapus acara?",
                    text: "Data peserta dan sertifikat akan ikut dihapus!",
                    icon: "warning",
                    buttons: true,
                    dangerMode: true,
                })
                .then((willDelete) => {
                    if (willDelete) {
                        $(".se-pre-con").fadeIn();
                        var dataform = new FormData();
                        dataform.append('id',id);
                        dataform.append('_token',$('meta[name="csrf-token"]').attr('content'));
                        axios.post("<?php echo e(route('hapus_acara')); ?>",dataform).then(resp => {
                            this.hapusCard(id);
                            $(".se-pre-con").fadeOut("slow");;
                            swal(resp.data.message, {
                        icon: "success",
                        });
                        }).catch(err =>{
                            $(".se-pre-con").fadeOut("slow");;
                            alert('err ='+err);
                        });
                    }
                });
            },
            hapusCard: function(id){
                $("#card-"+id).remove();
            }
        }
    });
    $(document).on("click",".btn_hapus", function(){
        swal({
            title: "Yakin menghapus acara?",
            text: "Once deleted, you will not be able to recover this imaginary file!",
            icon: "warning",
            buttons: true,
            dangerMode: true,
            })
            .then((willDelete) => {
            if (willDelete) {
                swal("Poof! Your imaginary file has been deleted!", {
                icon: "success",
                });
            } else {
                swal("Your imaginary file is safe!");
            }
        });
    });
</script>
<?php if(Session::get('message')): ?>
<script>
    swal("Berhasil",'<?php echo e(Session::get('message')); ?>' , "success");
</script>
<?php endif; ?>
<?php if(Session::get('reg')): ?>
<script>
    swal("<?php echo e(Session::get('reg')); ?>",'<?php echo e(Session::get('body')); ?>' , "success");
</script>
<?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('template.all', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\certifett\resources\views/frontend/agencyHome.blade.php ENDPATH**/ ?>