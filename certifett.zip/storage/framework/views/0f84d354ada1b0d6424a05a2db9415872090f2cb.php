<!DOCTYPE html>
<html lang="en">

<head>
    <link rel="preload" href="<?php echo e(asset('images/loader/Preloader_9.gif')); ?>" as="image">
    <link rel="stylesheet" href="<?php echo e(asset('css/all.blade.css')); ?>">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title><?php echo e(config('app.name')); ?> - <?php echo $__env->yieldContent('JudulHalaman'); ?></title>
    <?php echo $__env->yieldContent('CssTambahanBefore'); ?>
    
    <link rel="stylesheet" href="<?php echo e(asset("css/bootstrap.min.css")); ?>">
    <link rel="stylesheet" href="<?php echo e(asset("css/font-awesome-all.min.css")); ?>">
    
    
    <?php echo $__env->yieldContent('CssTambahanAfter'); ?>
    

</head>

<body class="d-flex flex-column">
    <div class="se-pre-con"></div>
    <?php echo $__env->yieldContent('header'); ?>
    <!-- <main> -->
    <div id="content" class="mb-2">
        <?php echo $__env->yieldContent('konten'); ?>
    </div>
    <!-- </main> -->
    <?php echo $__env->yieldContent('footer'); ?>
    <?php echo $__env->yieldContent('JsTambahanBefore'); ?>
    <script src="<?php echo e(asset('js/jquery-3.5.1.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/popper.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/bootstrap.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/sweetalert.min.js')); ?>"></script>
    <script>
        $(window).on('load',function() {
		    $(".se-pre-con").fadeOut("slow");;
	    });
    </script>
    <?php echo $__env->yieldContent('JsTambahanAfter'); ?>
</body>

</html>
<?php /**PATH C:\xampp\htdocs\certifett\resources\views/template/all.blade.php ENDPATH**/ ?>