
<?php $__env->startSection('JudulHalaman',"Admin Page"); ?>
<?php $__env->startSection(' CssTambahanAfter'); ?>
<link rel="stylesheet" href="<?php echo e(asset("css/style-yusuf.css")); ?>">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('konten'); ?>
<main>
  <div id="content">
    <article>
      <div id="judul">
        Peserta
      </div>
      <div id="penjelasan">
      Daftar peserta yang terdaftar dalam JS 101. buat sertifikat dengan cara mencentang kotak disamping kiri nama dan tekan tombol buat di sudut kanan atas tabel. Sertifikat yang telah dibuat dapat diunduh oleh peserta melalui www.domain.com/certificate dan www.ourdomain.com/cerfiticate
      </div>
      <div >

      </div>
    </article>
  </div>
</main>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('template.all', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\certifett\resources\views/frontend/admin.blade.php ENDPATH**/ ?>