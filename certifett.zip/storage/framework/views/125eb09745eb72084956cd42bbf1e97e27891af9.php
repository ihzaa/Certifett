<?php $__env->startSection('JudulHalaman','Home'); ?>

<?php $__env->startSection('CssTambahanAfter'); ?>
<link rel="stylesheet" href="<?php echo e(asset('css/rangeslider.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('css/landing.css')); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('header'); ?>
<?php echo $__env->make('template.components.nav-landing', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('konten'); ?>
<div id="isi" class="container">
    <div class="row text-center margin-when-small mt-4">
        <div class="col-12 col-sm-12 col-md-10 col-lg-8 col-xl-8 ml-auto mr-auto ">
            <h1 class="text-hijau font-weight-normal judul">Verifikasi Sertifikat</h1>
            <form action="/certificate/" action="post" id="form_id">
                <p class="text-normal">Verifikasi sertifikat yang dibuat dengan certifett menggunakan ID sertifikat</p>
                <div class="input-group input-group-lg mb-3 text-hijau mt-4 pt-4">
                    <div class="input-group-prepend">
                        <span
                            class="input-group-text transparent text-hijau hash border-radius-c border-radius-tanpa-kanan border-hijau"
                            id="basic-addon1">#</span>
                    </div>
                    <?php echo csrf_field(); ?>
                    <input id="idSertifikat" type="text"
                        class="form-control kolom-input-id hash border-radius-c border-radius-tanpa-kiri border-hijau"
                        aria-label="Username" aria-describedby="basic-addon1">
                </div>
            </form>
        </div>
    </div>
    <div class="row" id="WhatIsIt">
        <div class="col-xs-12 col-sm-12 col-md-12 col-lg-6 my-auto">
            <h1><?php echo e(config('app.name')); ?>.</h1>
            <h1>Certificate Factory</h1>
            <p><?php echo e(config('app.name')); ?> adalah layanan untuk mempermudah pembuatan & verikasi sertifikat. Layanan kami dapat digunakan
                oleh sebuah instansi untuk membuat & menyebarkan sertifikat ke peserta acara dengan mudah. Sertifikat
                yang dibuat melalui certifett dapat diverikasi ketika peserta membutuhkannya sehingga keasliannya
                terjamin.</p>
        </div>
        <div class="col-xs-12 col-sm-12 col-md-12 col-lg-6 my-auto">
            <img class="img-fluid" src="<?php echo e(asset('images/Manufacturing Process-pana.png')); ?>" alt="">
        </div>
    </div>
    <div class="row" id="GettingStarted">
        <div class="col-xs-12 col-sm-12 col-md-12 col-lg-6 my-auto d-none d-sm-none d-md-none d-lg-block d-xl-block">
            <img class="img-fluid" src="<?php echo e(asset('images/Setup Wizard-pana.png')); ?>" alt="">
        </div>
        <div class="col-xs-12 col-sm-12 col-md-12 col-lg-6 my-auto">
            <h1>Getting Started</h1>
            <div class="row">
                <div class="col-1">
                    <span class="fa-stack">
                        <i class="fa fa-circle fa-stack-2x"></i>
                        <span class="fa fa-stack-1x fa-inverse">1</span>
                    </span>
                </div>
                <div class="col-11 pl-4">
                    <p>
                        Untuk mulai membuat sertifikat melalui certifett instansi harus mendaftar terlebih dahulu (no
                        surprise
                        here.)
                    </p>
                </div>
            </div>
            <div class="row">
                <div class="col-1">
                    <span class="fa-stack">
                        <i class="fa fa-circle fa-stack-2x"></i>
                        <span class="fa fa-stack-1x fa-inverse">2</span>
                    </span>
                </div>
                <div class="col-11 pl-4">
                    <p>
                        Buat acara baru, dan inputkan peserta. Peserta dapat diinput melalui link sharing atau file .csv
                        yang biasanya diimport dari Google Form
                    </p>
                </div>
            </div>
            <div class="row">
                <div class="col-1">
                    <span class="fa-stack">
                        <i class="fa fa-circle fa-stack-2x"></i>
                        <span class="fa fa-stack-1x fa-inverse">3</span>
                    </span>
                </div>
                <div class="col-11 pl-4">
                    <p>
                        Peserta dapat mengunduh atau memverifikasi sertifikat melalui <?php echo e(config('app.url')); ?> atau
                        self hosted front-end.
                    </p>
                </div>
            </div>
        </div>
        <div class="col-xs-12 col-sm-12 col-md-12 col-lg-6 my-auto d-xl-none d-lg-none">
            <img class="img-fluid" src="<?php echo e(asset('images/Setup Wizard-pana.png')); ?>" alt="">
        </div>
    </div>
    <div class="row mt-5" id="pricing">
        <div class="col-xs-12 col-sm-12 col-md-12 col-lg-6 my-auto">
            <h1>Pricing Calculator</h1>
            <p>tarik slider dibawah untuk menghitung harga.</p>
            <div class="slidecontainer">
                <input id="slider" type="range" min="10" max="1000" step="10" value="100" style="width: 100%">
            </div>
            <p class="text-right">25K/10 orang</p>
            <div class="row">
                <div class="col-xs-12 col-sm-12 col-md-12 col-lg-6 col-xl-6">
                    <h3 class="d-flex align-items-center"><img class="img-fluid mr-2" width="45"
                            src="<?php echo e(asset('icons/face-24px.png')); ?>" alt="">
                        <span id="demo"></span>
                        Peserta</h3>
                </div>
                <div class="col-xs-12 col-sm-12 col-md-12 col-lg-6 col-xl-6">
                    <h3 class="d-flex"><span id="TotalHarga" class="ml-auto">Rp. 250.000</span></h3>
                </div>
            </div>
        </div>
        <div class="col-xs-12 col-sm-12 col-md-12 col-lg-6 my-auto">
            <img class="img-fluid" src="<?php echo e(asset('images/Calculator-pana.png')); ?>" alt="">
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('footer'); ?>
<?php echo $__env->make('template.components.footer-common', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('JsTambahanAfter'); ?>
<script src="<?php echo e(asset('js/rangeslider.js')); ?>"></script>
<script src="<?php echo e(asset('js/page/landing.js')); ?>"></script>
<?php if(Session::get('message')): ?>
<script>
    swal("<?php echo e(Session::get('title')); ?>",'<?php echo e(Session::get('message')); ?>' , "<?php echo e(Session::get('logo')); ?>");
</script>

<?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('template.all', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\certifett\resources\views/frontend/landing.blade.php ENDPATH**/ ?>