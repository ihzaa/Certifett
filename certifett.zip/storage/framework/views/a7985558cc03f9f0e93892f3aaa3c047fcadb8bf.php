
<?php $__env->startSection('JudulHalaman',"Certifett"); ?>
<?php $__env->startSection(' CssTambahanAfter'); ?>
<link rel="stylesheet" href="<?php echo e(asset("css/style-yusuf.css")); ?>">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('konten'); ?>
  <div id="content">
    <article class="text-center">
      <h1 id="judul2">
        Pilih Jenis Akun
      </h1>
      <div class="d-flex justify-content-center text-left">
        <div class="card image">
          <img class="img-fluid" src="<?php echo e(asset("images/Team-pana@2x.png")); ?>">
          <h2 class="judul">Instansi</h2>
          <p>
          Daftar sebagai akun instansi untuk dapat membuat sertifikat.
          </p>
        </div>
        <div class="card">
          <img class="img-fluid" src="<?php echo e(asset("images/Curious-pana@2x.png")); ?>">
          <h2 class="judul">Dasar</h2>
          <p>
          Daftar sebagai akun dasar untuk dapat melihat semua sertifikat yang terikat dengan email anda.
          </p>
        </div>
      </div>
      <h4 id="text1">sudah punya akun?</h4>
      <button type="button" class="btn btn-outline-dark masuk">Masuk</button>
    </article>
  </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('template.all', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\certifett\resources\views/frontend/pilihAkun.blade.php ENDPATH**/ ?>