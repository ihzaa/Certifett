<?php $__env->startSection('JudulHalaman','Masuk'); ?>

<?php $__env->startSection('CssTambahanAfter'); ?>
<link rel="stylesheet" href="<?php echo e(asset('css/style-yusuf.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('css/brands.css')); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('header'); ?>
<?php echo $__env->make('template.components.nav-common', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('konten'); ?>
<div class="container">
    <article class="text-center auth">
        <h1 id="judul2">
            Masuk
        </h1>
        <form id="login" method="POST" action="<?php echo e(route('login')); ?>">
            <?php echo csrf_field(); ?>
            <div class="form-group">
                <div class="form-group">
                    <input type="email" name="email" class="form-control mx-auto" placeholder="Email">
                </div>
                <div class="form-group">
                    <input type="password" name="password" class="form-control mx-auto" placeholder="Password">
                </div>
                <img src='<?php echo e(asset("images/Savings-pana.png")); ?>'>
                <button type="submit" class="btn btn-outline-dark btn-auth">Masuk</button>
                
                <h4 id="text1">Belum punya akun? <a href="<?php echo e(route('register')); ?>"><span>daftar</span></a></h4>

        </form>

    </article>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('JsTambahanAfter'); ?>
<script>
    $("#login").on("submit",function(){
        $(".se-pre-con").fadeIn();
    });
</script>
<?php if(Session::get('error')): ?>
<script>
    swal("Email/Password Salah", "Silahkan Coba Lagi!", "error");
</script>
<?php endif; ?>
<?php if($errors->any()): ?>
<script>
    let arr = new Array();
    <?php foreach($errors->all() as $e){ ?>
        arr.push('<?php echo $e; ?>');
    <?php } ?>

    let ul_el = document.createElement("UL");

    arr.forEach(ar =>{
        ul_el.innerHTML += '<li>'+ar+'</li>';
    });

    swal({
        title: "Sorry...",
        content: ul_el,
        icon: "error",
    });
</script>

<?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('template.all', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\certifett\resources\views/auth/login.blade.php ENDPATH**/ ?>